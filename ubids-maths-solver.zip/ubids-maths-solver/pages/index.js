import { useState, useRef, useCallback } from "react";
import Head from "next/head";
import styles from "../styles/Home.module.css";

// ─── Parse AI solution text into structured steps ────────────────────────────
function parseSteps(text) {
  const lines = text.split("\n");
  const steps = [];
  let currentStep = null;
  let finalAnswer = null;

  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;

    // Detect "Final Answer"
    if (/^(final answer|answer|result)[:\s]/i.test(line)) {
      const val = line.replace(/^(final answer|answer|result)[:\s]*/i, "").trim();
      if (val) finalAnswer = val;
      currentStep = null;
      continue;
    }

    // Detect numbered step: "Step 1:" or "1." or "1)"
    const stepMatch = line.match(/^(?:step\s*)?(\d+)[.:)]\s*(.*)/i);
    if (stepMatch) {
      currentStep = {
        number: parseInt(stepMatch[1]),
        heading: stepMatch[2] || `Step ${stepMatch[1]}`,
        content: [],
        implicit: false,
      };
      steps.push(currentStep);
      continue;
    }

    // Detect inline math (contains operators, equals signs, etc.)
    const isMath =
      /[=+\-×÷^\\{}]/.test(line) &&
      line.length < 220 &&
      !/^[A-Z][a-z]/.test(line); // avoid flagging sentences

    if (currentStep) {
      currentStep.content.push({ type: isMath ? "math" : "text", value: line });
    } else {
      // Introductory / overview text before first step
      if (steps.length === 0 || !steps[steps.length - 1].implicit) {
        const overviewStep = {
          number: null,
          heading: "Overview",
          content: [{ type: "text", value: line }],
          implicit: true,
        };
        steps.push(overviewStep);
        currentStep = overviewStep;
      } else {
        steps[steps.length - 1].content.push({ type: "text", value: line });
      }
    }
  }

  return { steps, finalAnswer };
}

// ─── PDF Export ───────────────────────────────────────────────────────────────
async function exportPDF(question, solutionText) {
  if (!window.jspdf) {
    await new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js";
      s.onload = resolve;
      s.onerror = reject;
      document.head.appendChild(s);
    });
  }

  const { jsPDF } = window.jspdf;
  const doc = new jsPDF({ unit: "mm", format: "a4" });

  const margin = 25.4; // 1 inch
  const pageW = 210;
  const usableW = pageW - 2 * margin;
  let y = margin;

  const checkPage = (needed = 8) => {
    if (y + needed > 297 - margin) {
      doc.addPage();
      y = margin;
    }
  };

  const addLine = (text, opts = {}) => {
    const {
      size = 12,
      style = "normal",
      color = [0, 0, 0],
      lineH = 7,
    } = opts;
    doc.setFontSize(size);
    doc.setFont("times", style);
    doc.setTextColor(...color);
    const lines = doc.splitTextToSize(String(text), usableW);
    lines.forEach((line) => {
      checkPage(lineH);
      doc.text(line, margin, y);
      y += lineH;
    });
  };

  // ── Header ──
  doc.setDrawColor(15, 14, 12);
  doc.setLineWidth(0.6);
  doc.line(margin, margin - 5, pageW - margin, margin - 5);

  addLine("Ubids Maths Solver", { size: 20, style: "bold", color: [15, 14, 12], lineH: 11 });
  addLine("Step-by-Step Solution", { size: 10, style: "italic", color: [30, 107, 107], lineH: 6 });
  addLine(`Date: ${new Date().toLocaleDateString("en-GB", { day:"numeric", month:"long", year:"numeric" })}`, {
    size: 9, color: [150, 130, 80], lineH: 6,
  });

  y += 4;
  doc.setLineWidth(0.4);
  doc.setDrawColor(200, 146, 42);
  doc.line(margin, y, pageW - margin, y);
  y += 10;

  // ── Problem ──
  addLine("PROBLEM", { size: 9, style: "bold", color: [30, 107, 107], lineH: 6 });
  doc.setFillColor(245, 241, 232);
  const qLines = doc.setFontSize(12).splitTextToSize(question || "(Image problem)", usableW - 10);
  const qH = qLines.length * 7 + 10;
  checkPage(qH + 4);
  doc.rect(margin, y, usableW, qH, "F");
  doc.setDrawColor(200, 146, 42);
  doc.setLineWidth(2);
  doc.line(margin, y, margin, y + qH);
  doc.setLineWidth(0.4);
  y += 6;
  addLine(question || "(Image problem)", { size: 12, lineH: 7 });
  y += 8;

  // ── Solution ──
  addLine("SOLUTION", { size: 9, style: "bold", color: [30, 107, 107], lineH: 7 });
  y += 2;

  const cleanText = solutionText
    .replace(/\*\*/g, "")
    .replace(/\*/g, "");

  cleanText.split("\n").forEach((rawLine) => {
    const line = rawLine.trim();
    if (!line) { y += 3; return; }

    const stepMatch = line.match(/^(?:step\s*)?(\d+)[.:)]\s*(.*)/i);
    if (stepMatch) {
      y += 3;
      checkPage(10);
      doc.setFillColor(30, 107, 107);
      doc.rect(margin, y - 4, usableW, 8, "F");
      doc.setFont("times", "bold");
      doc.setFontSize(10);
      doc.setTextColor(255, 255, 255);
      doc.text(`Step ${stepMatch[1]}: ${stepMatch[2]}`, margin + 3, y + 0.5);
      y += 10;
    } else if (/^(final answer|answer|result)[:\s]/i.test(line)) {
      y += 6;
      checkPage(16);
      const val = line.replace(/^(final answer|answer|result)[:\s]*/i, "").trim();
      doc.setFillColor(30, 107, 107);
      doc.rect(margin, y - 4, usableW, 14, "F");
      doc.setFont("times", "bold");
      doc.setFontSize(9);
      doc.setTextColor(200, 210, 200);
      doc.text("FINAL ANSWER", margin + 4, y + 0.5);
      doc.setFont("times", "bold");
      doc.setFontSize(13);
      doc.setTextColor(255, 255, 255);
      doc.text(val, margin + 4, y + 8);
      y += 18;
    } else {
      addLine(line, { size: 12, lineH: 7 });
    }
  });

  // ── Footer on every page ──
  const total = doc.internal.getNumberOfPages();
  for (let i = 1; i <= total; i++) {
    doc.setPage(i);
    doc.setDrawColor(204, 197, 176);
    doc.setLineWidth(0.3);
    doc.line(margin, 297 - 16, pageW - margin, 297 - 16);
    doc.setFontSize(8);
    doc.setFont("times", "italic");
    doc.setTextColor(180, 180, 180);
    doc.text("Ubids Maths Solver · Powered by Claude AI", margin, 297 - 9);
    doc.text(`Page ${i} of ${total}`, pageW - margin - 20, 297 - 9);
  }

  doc.save("ubids-maths-solution.pdf");
}

// ─── Word Export ──────────────────────────────────────────────────────────────
function exportWord(question, solutionText) {
  const esc = (s) => s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  const clean = solutionText.replace(/\*\*/g, "").replace(/\*/g, "");

  const bodyLines = clean
    .split("\n")
    .map((raw) => {
      const line = raw.trim();
      if (!line) return "<p>&nbsp;</p>";
      const stepMatch = line.match(/^(?:step\s*)?(\d+)[.:)]\s*(.*)/i);
      if (stepMatch) return `<h3 class="step">Step ${stepMatch[1]}: ${esc(stepMatch[2])}</h3>`;
      if (/^(final answer|answer|result)[:\s]/i.test(line)) {
        const val = line.replace(/^(final answer|answer|result)[:\s]*/i, "").trim();
        return `<div class="final"><span class="finallabel">FINAL ANSWER</span><div class="finalval">${esc(val)}</div></div>`;
      }
      return `<p>${esc(line)}</p>`;
    })
    .join("\n");

  const html = `<!DOCTYPE html>
<html xmlns:o="urn:schemas-microsoft-com:office:office"
      xmlns:w="urn:schemas-microsoft-com:office:word"
      xmlns="http://www.w3.org/TR/REC-html40">
<head>
<meta charset="UTF-8">
<title>Ubids Maths Solver - Solution</title>
<!--[if gte mso 9]><xml>
  <w:WordDocument>
    <w:View>Print</w:View>
    <w:Zoom>100</w:Zoom>
    <w:DoNotOptimizeForBrowser/>
  </w:WordDocument>
</xml><![endif]-->
<style>
  @page { size: A4; margin: 1in; }
  body { font-family:"Times New Roman",serif; font-size:12pt; line-height:1.15; color:#000; }
  h1   { font-size:20pt; font-weight:bold; color:#0f0e0c; border-bottom:2pt solid #0f0e0c; padding-bottom:5pt; margin-bottom:4pt; }
  h2   { font-size:11pt; color:#1e6b6b; font-weight:bold; letter-spacing:0.15em; text-transform:uppercase; margin:12pt 0 6pt; }
  h3.step { font-size:12pt; color:#fff; background:#1e6b6b; padding:4pt 8pt; margin:12pt 0 6pt; font-weight:bold; }
  p    { margin:4pt 0; }
  .meta { font-size:9pt; color:#888; margin-bottom:2pt; }
  .qbox { background:#f5f1e8; border-left:4pt solid #c8922a; padding:8pt 12pt; margin:8pt 0 14pt; }
  .final { background:#1e6b6b; color:#fff; padding:10pt 14pt; margin-top:16pt; }
  .finallabel { font-size:8pt; letter-spacing:0.2em; text-transform:uppercase; display:block; opacity:0.75; margin-bottom:4pt; }
  .finalval { font-size:14pt; font-weight:bold; }
  .footer { margin-top:28pt; border-top:0.5pt solid #ccc; padding-top:6pt; font-size:8pt; color:#aaa; font-style:italic; }
</style>
</head>
<body>
<h1>Ubids Maths Solver</h1>
<p class="meta">Generated: ${new Date().toLocaleString("en-GB")}</p>
<p class="meta">Powered by Claude AI · A4 · Times New Roman 12pt · 1-inch margins</p>
<h2>Problem</h2>
<div class="qbox"><p>${esc(question || "Image problem")}</p></div>
<h2>Step-by-Step Solution</h2>
${bodyLines}
<div class="footer">Ubids Maths Solver · All solutions generated by Claude AI · For educational use</div>
</body>
</html>`;

  const blob = new Blob([html], { type: "application/msword" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "ubids-maths-solution.doc";
  a.click();
  URL.revokeObjectURL(url);
}

// ─── Main Page Component ──────────────────────────────────────────────────────
export default function Home() {
  const [question, setQuestion] = useState("");
  const [level, setLevel] = useState("standard");
  const [image, setImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [rawSolution, setRawSolution] = useState("");
  const [parsed, setParsed] = useState(null);
  const [error, setError] = useState("");
  const [history, setHistory] = useState([]);
  const fileRef = useRef();

  const handleImageUpload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const dataUrl = ev.target.result;
      const base64 = dataUrl.split(",")[1];
      setImage({ base64, dataUrl, type: file.type });
    };
    reader.readAsDataURL(file);
  };

  const solve = useCallback(async () => {
    if (!question.trim() && !image) return;
    setLoading(true);
    setError("");
    setRawSolution("");
    setParsed(null);

    try {
      const body = {
        question: question.trim(),
        level,
        ...(image && { imageBase64: image.base64, imageType: image.type }),
      };

      const res = await fetch("/api/solve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to get solution");

      setRawSolution(data.solution);
      setParsed(parseSteps(data.solution));
      if (question.trim()) {
        setHistory((h) => [question.trim(), ...h.filter((x) => x !== question.trim()).slice(0, 6)]);
      }
    } catch (e) {
      setError("Could not solve: " + e.message);
    } finally {
      setLoading(false);
    }
  }, [question, image, level]);

  const clear = () => {
    setQuestion("");
    setImage(null);
    setRawSolution("");
    setParsed(null);
    setError("");
    if (fileRef.current) fileRef.current.value = "";
  };

  const levels = [
    { key: "simple",   label: "Simple" },
    { key: "standard", label: "Standard" },
    { key: "advanced", label: "Advanced" },
  ];

  return (
    <>
      <Head>
        <title>Ubids Maths Solver — AI Step-by-Step Solutions</title>
        <meta name="description" content="Solve any maths problem step by step using AI. Free, fast, and accurate." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <div className={styles.appShell}>
        {/* ─── Header ─── */}
        <header className={styles.header}>
          <div className={styles.headerLeft}>
            <h1 className={styles.logo}>
              <span>Ubids</span> Maths Solver
            </h1>
            <p className={styles.tagline}>AI-Powered · Step-by-Step · Instant Solutions</p>
          </div>
          <div className={styles.headerSymbols}>∑ ∫ √ π ∞</div>
        </header>

        {/* ─── History ─── */}
        {history.length > 0 && (
          <div className={styles.historyStrip}>
            <span className={styles.historyLabel}>Recent:</span>
            {history.map((h, i) => (
              <button
                key={i}
                className={styles.historyChip}
                onClick={() => setQuestion(h)}
                title={h}
              >
                ↩ {h}
              </button>
            ))}
          </div>
        )}

        {/* ─── Input Panel ─── */}
        <div className={styles.panel}>
          <span className={styles.panelLabel}>// Enter your maths problem</span>

          <textarea
            className={styles.mathInput}
            placeholder={`Try these examples:\n• Solve: 2x² + 5x − 3 = 0\n• Find the derivative of sin(x) · cos(x)\n• Integrate: ∫ x² dx from 0 to 3\n• Simplify: (a + b)³`}
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && e.ctrlKey) solve(); }}
          />

          {/* Explanation level */}
          <div className={styles.levelRow}>
            <span className={styles.levelRowLabel}>Level:</span>
            {levels.map(({ key, label }) => (
              <button
                key={key}
                className={`${styles.levelBtn} ${level === key ? styles.levelBtnActive : ""}`}
                onClick={() => setLevel(key)}
              >
                {label}
              </button>
            ))}
          </div>

          {/* Image upload */}
          <div
            className={`${styles.uploadZone} ${image ? styles.uploadZoneActive : ""}`}
            onClick={() => fileRef.current?.click()}
          >
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              style={{ display: "none" }}
              onChange={handleImageUpload}
            />
            {image ? (
              <>
                <p className={styles.uploadZoneTextActive}>✓ Image uploaded — ready to solve</p>
                <img src={image.dataUrl} alt="Math problem" className={styles.uploadPreview} />
              </>
            ) : (
              <p className={styles.uploadZoneText}>
                📷 Or click here to upload a photo / scan of your maths problem
              </p>
            )}
          </div>

          {/* Action row */}
          <div className={styles.solveRow}>
            <button
              className={styles.solveBtn}
              onClick={solve}
              disabled={loading || (!question.trim() && !image)}
            >
              {loading ? "Solving…" : "Solve →"}
            </button>

            {(question || image || rawSolution) && (
              <button className={styles.clearBtn} onClick={clear}>
                ✕ Clear
              </button>
            )}

            <span className={styles.shortcutHint}>Ctrl + Enter to solve</span>
          </div>
        </div>

        {/* ─── Error ─── */}
        {error && (
          <div className={styles.errorBox}>⚠ {error}</div>
        )}

        {/* ─── Loading ─── */}
        {loading && (
          <div className={styles.thinkingBar}>
            <div className={styles.dot} />
            <div className={styles.dot} />
            <div className={styles.dot} />
            Computing solution…
          </div>
        )}

        {/* ─── Solution ─── */}
        {parsed && !loading && (
          <div className={styles.solutionPanel}>
            <div className={styles.solutionHeader}>
              <div className={styles.solutionTitle}>Step-by-Step Solution</div>
              <div className={styles.solutionMeta}>
                {parsed.steps.filter((s) => !s.implicit).length} steps · {level} mode
              </div>
            </div>

            <div className={styles.solutionBody}>
              {parsed.steps.map((step, i) => (
                <div key={i} className={styles.stepBlock}>
                  {!step.implicit ? (
                    <div className={styles.stepHeading}>
                      <span className={styles.stepNumber}>{step.number || i + 1}</span>
                      {step.heading}
                    </div>
                  ) : (
                    <div className={styles.stepHeading} style={{ color: "#777", fontWeight: 400 }}>
                      {step.heading}
                    </div>
                  )}

                  <div className={styles.stepContent}>
                    {step.content.map((c, j) =>
                      c.type === "math" ? (
                        <code key={j} className={styles.mathFormula}>{c.value}</code>
                      ) : (
                        <p key={j} className={styles.stepText}>{c.value}</p>
                      )
                    )}
                  </div>
                </div>
              ))}

              {parsed.finalAnswer && (
                <div className={styles.finalAnswer}>
                  <div className={styles.finalAnswerLabel}>Final Answer</div>
                  <div className={styles.finalAnswerValue}>{parsed.finalAnswer}</div>
                </div>
              )}
            </div>

            {/* Export */}
            <div className={styles.exportRow}>
              <span className={styles.exportLabel}>Export:</span>
              <button
                className={`${styles.exportBtn} ${styles.exportPdf}`}
                onClick={() => exportPDF(question || "Image problem", rawSolution)}
              >
                📄 Download PDF
              </button>
              <button
                className={`${styles.exportBtn} ${styles.exportWord}`}
                onClick={() => exportWord(question || "Image problem", rawSolution)}
              >
                📝 Download Word
              </button>
            </div>
          </div>
        )}

        {/* ─── Footer ─── */}
        <footer className={styles.footer}>
          <p className={styles.footerText}>© {new Date().getFullYear()} Ubids Maths Solver · Powered by Claude AI</p>
          <p className={styles.footerText}>A4 · Times New Roman 12pt · 1-inch margins</p>
        </footer>
      </div>
    </>
  );
}
