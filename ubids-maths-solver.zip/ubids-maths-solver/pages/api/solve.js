// pages/api/solve.js
// ─────────────────────────────────────────────────────────────────────────────
// Secure server-side API route — the ANTHROPIC_API_KEY never reaches the browser
// ─────────────────────────────────────────────────────────────────────────────

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const { question, imageBase64, imageType, level } = req.body;

  if (!question && !imageBase64) {
    return res.status(400).json({ error: "No question or image provided" });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({ error: "API key not configured on server" });
  }

  const levelInstructions = {
    simple:   "Explain each step in very simple language, as if teaching a 12-year-old. Avoid jargon. Use everyday words.",
    standard: "Provide a clear, thorough step-by-step solution at high-school / early university level.",
    advanced: "Use formal mathematical notation and rigorous proofs. Reference theorems and lemmas where applicable.",
  }[level] || "Provide a clear step-by-step solution.";

  const systemPrompt = `You are Ubids Maths Solver, an expert mathematics tutor. ${levelInstructions}

Format your response EXACTLY like this structure:
Step 1: [Step name]
[Explanation of this step]
[Formula or equation if applicable]

Step 2: [Step name]
[Explanation]
[Formula]

...continue for all steps...

Final Answer: [concise final answer]

Rules:
- Use plain text for formulas (e.g. x^2 + 3x = 10, not LaTeX)
- Each step must be on its own numbered block
- Be accurate, thorough, and educational
- Always end with "Final Answer:"`;

  const userContent = [];

  if (imageBase64) {
    userContent.push({
      type: "image",
      source: {
        type: "base64",
        media_type: imageType || "image/jpeg",
        data: imageBase64,
      },
    });
    userContent.push({
      type: "text",
      text: question?.trim() || "Please solve the math problem shown in this image, step by step.",
    });
  } else {
    userContent.push({ type: "text", text: question.trim() });
  }

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 2000,
        system: systemPrompt,
        messages: [{ role: "user", content: userContent }],
      }),
    });

    if (!response.ok) {
      const errData = await response.json();
      throw new Error(errData.error?.message || "Anthropic API error");
    }

    const data = await response.json();
    const text = data.content?.map((b) => b.text || "").join("") || "";

    return res.status(200).json({ solution: text });
  } catch (err) {
    console.error("Solve error:", err.message);
    return res.status(500).json({ error: err.message });
  }
}
