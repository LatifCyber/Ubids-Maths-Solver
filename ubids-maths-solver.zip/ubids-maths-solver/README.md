# 🧮 Ubids Maths Solver

An AI-powered mathematics solver that provides step-by-step solutions to any maths problem. Built with Next.js and powered by Claude AI.

![Ubids Maths Solver](https://img.shields.io/badge/Powered%20by-Claude%20AI-teal?style=flat-square)
![Next.js](https://img.shields.io/badge/Next.js-14-black?style=flat-square)
![License](https://img.shields.io/badge/License-MIT-gold?style=flat-square)

---

## ✨ Features

- 🤖 **AI-powered solving** — step-by-step solutions via Claude AI
- 📷 **Image upload** — photograph or scan a handwritten problem
- 🎚️ **3 explanation levels** — Simple, Standard, Advanced
- 📄 **PDF export** — A4, Times New Roman 12pt, 1-inch margins
- 📝 **Word export** — Formatted `.doc` file
- 📱 **Fully responsive** — works on mobile and desktop
- 🔒 **Secure** — API key stays server-side, never exposed to browser

---

## 🚀 Deploy to Vercel (Recommended — Free)

### Step 1: Fork or Push to GitHub

```bash
# Clone this project
git clone https://github.com/YOUR_USERNAME/ubids-maths-solver.git
cd ubids-maths-solver

# OR if starting fresh:
git init
git add .
git commit -m "Initial commit — Ubids Maths Solver"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/ubids-maths-solver.git
git push -u origin main
```

### Step 2: Get Your Anthropic API Key

1. Go to [https://console.anthropic.com](https://console.anthropic.com)
2. Sign up / log in
3. Click **"API Keys"** → **"Create Key"**
4. Copy the key (starts with `sk-ant-...`)

### Step 3: Deploy on Vercel

1. Go to [https://vercel.com](https://vercel.com) and sign in with GitHub
2. Click **"New Project"**
3. Select your `ubids-maths-solver` repository
4. Click **"Environment Variables"** and add:
   ```
   Name:  ANTHROPIC_API_KEY
   Value: sk-ant-your-key-here
   ```
5. Click **"Deploy"** ✅

Your site will be live at: `https://ubids-maths-solver.vercel.app`

---

## 💻 Run Locally

### Prerequisites
- Node.js 18+ ([download here](https://nodejs.org))
- An Anthropic API key

### Setup

```bash
# 1. Clone the repository
git clone https://github.com/YOUR_USERNAME/ubids-maths-solver.git
cd ubids-maths-solver

# 2. Install dependencies
npm install

# 3. Set up your API key
cp .env.example .env.local
# Then edit .env.local and replace with your real API key:
# ANTHROPIC_API_KEY=sk-ant-your-key-here

# 4. Start the development server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### Build for Production

```bash
npm run build
npm start
```

---

## 📁 Project Structure

```
ubids-maths-solver/
├── pages/
│   ├── index.js          ← Main UI page
│   ├── _app.js           ← App wrapper
│   └── api/
│       └── solve.js      ← Secure backend API route (hides API key)
├── styles/
│   ├── globals.css       ← Global styles + fonts
│   └── Home.module.css   ← Page-specific styles
├── public/               ← Static files (favicon, etc.)
├── .env.example          ← Template for environment variables
├── .env.local            ← Your actual API key (NEVER commit this)
├── .gitignore            ← Excludes .env.local from git
├── next.config.js        ← Next.js configuration
├── package.json          ← Dependencies
└── README.md             ← This file
```

---

## 🔒 Security

- The `ANTHROPIC_API_KEY` is stored in `.env.local` and used **only on the server** inside `pages/api/solve.js`
- It is **never sent to the browser**
- `.env.local` is listed in `.gitignore` so it will **never be committed to GitHub**
- On Vercel, the key is stored as an encrypted environment variable

---

## 📄 Document Export Specs

Both PDF and Word exports follow these formatting rules:

| Setting | Value |
|---------|-------|
| Paper size | A4 (210 × 297mm) |
| Margins | 1 inch (25.4mm) all sides |
| Font | Times New Roman |
| Font size | 12pt body, 20pt title |
| Line spacing | 1.15 |

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|------------|
| Framework | Next.js 14 |
| AI | Claude claude-sonnet-4-20250514 via Anthropic API |
| PDF | jsPDF (CDN, browser-side) |
| Word | HTML-to-DOC (browser-side) |
| Hosting | Vercel (recommended) |
| Styling | CSS Modules + Google Fonts |

---

## 🤝 Usage Tips

- **Simple mode** — great for students learning a topic for the first time
- **Standard mode** — detailed working suitable for homework and exams
- **Advanced mode** — rigorous proofs and formal notation for university level
- **Image upload** — take a photo of a textbook problem or handwritten question
- Press **Ctrl + Enter** to solve quickly

---

## 📝 License

MIT License — free to use, modify, and distribute.

---

*Built with ❤️ · Powered by Claude AI*
